let slides = [];
let currentIndex = 0;

fetch('/api/slides')
  .then(res => res.json())
  .then(data => {
    slides = data;
    renderSlide(currentIndex);
  });

function renderSlide(index) {
  const container = document.getElementById('slider');
  const slide = slides[index];
  container.innerHTML = `
    <div class="slide active" style="background-color: ${slide.backgroundColor}">
      <h2>${slide.title}</h2>
      <p>${slide.description}</p>
      <iframe src="${slide.iframeUrl}" allowfullscreen></iframe>
    </div>
  `;
}

document.getElementById('prevBtn').addEventListener('click', () => {
  currentIndex = (currentIndex - 1 + slides.length) % slides.length;
  renderSlide(currentIndex);
});

document.getElementById('nextBtn').addEventListener('click', () => {
  currentIndex = (currentIndex + 1) % slides.length;
  renderSlide(currentIndex);
});