const express = require('express');
const fs = require('fs');
const app = express();
const PORT = 3000;

app.use(express.static('public'));
app.use('/admin', express.static('admin'));
app.use(express.json());

app.get('/api/slides', (req, res) => {
  const data = JSON.parse(fs.readFileSync('slides.json'));
  res.json(data);
});

app.post('/api/slides', (req, res) => {
  const slides = JSON.parse(fs.readFileSync('slides.json'));
  slides.push(req.body);
  fs.writeFileSync('slides.json', JSON.stringify(slides, null, 2));
  res.sendStatus(200);
});

app.delete('/api/slides/:index', (req, res) => {
  const index = parseInt(req.params.index);
  const slides = JSON.parse(fs.readFileSync('slides.json'));
  slides.splice(index, 1);
  fs.writeFileSync('slides.json', JSON.stringify(slides, null, 2));
  res.sendStatus(200);
});

app.listen(PORT, () => console.log(`Servidor corriendo en http://localhost:${PORT}`));