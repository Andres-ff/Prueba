function loadSlides() {
  fetch('/api/slides')
    .then(res => res.json())
    .then(data => {
      const list = document.getElementById('slideList');
      list.innerHTML = '';
      data.forEach((slide, index) => {
        const item = document.createElement('li');
        item.innerHTML = `${slide.title} <button onclick="deleteSlide(${index})">Eliminar</button>`;
        list.appendChild(item);
      });
    });
}

document.getElementById('slideForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const slide = {
    title: document.getElementById('title').value,
    description: document.getElementById('description').value,
    backgroundColor: document.getElementById('backgroundColor').value,
    iframeUrl: document.getElementById('iframeUrl').value
  };
  fetch('/api/slides', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(slide)
  }).then(() => {
    this.reset();
    loadSlides();
  });
});

function deleteSlide(index) {
  fetch('/api/slides/' + index, { method: 'DELETE' }).then(loadSlides);
}

loadSlides();